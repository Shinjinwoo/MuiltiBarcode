//
//  CameraViewController2.h
//  nexacroApp
//
//  Created by 신진우 on 2023/02/16.
//  Copyright © 2023 com.tobesoft. All rights reserved.
//
//

#import "CameraViewController2.h"
#import <AVFoundation/AVFoundation.h>
#import <CoreVideo/CoreVideo.h>
#import "UIUtilities.h"
#import "AppDelegate.h"
#import "MultiQRBarcodePlugin.h"

#define SERVICE_ID   @"scan"
//#define CODE_ERROR -1
//#define CODE_SUCESS 0

@import MLImage;
@import MLKit;

NS_ASSUME_NONNULL_BEGIN

static NSString *const videoDataOutputQueueLabel = @"com.google.mlkit.visiondetector.VideoDataOutputQueue";
static NSString *const sessionQueueLabel = @"com.google.mlkit.visiondetector.SessionQueue";


@interface CameraViewController2 () <AVCaptureVideoDataOutputSampleBufferDelegate>

typedef NS_ENUM(NSInteger, Detector) {
    DetectorOnDeviceBarcode
};

@property(nonatomic) NSArray *detectors;
@property(nonatomic) Detector currentDetector;
@property(nonatomic) bool isUsingFrontCamera;
@property(nonatomic, nonnull) AVCaptureVideoPreviewLayer *previewLayer;
@property(nonatomic) AVCaptureSession *captureSession;
@property(nonatomic) dispatch_queue_t sessionQueue;
@property(nonatomic) UIView *annotationOverlayView;
@property(nonatomic) UIImageView *previewOverlayView;
@property(weak, nonatomic) IBOutlet UIView *cameraView;
@property(nonatomic) CMSampleBufferRef lastFrame;




@property (weak, nonatomic) IBOutlet UIButton *cameraBtn;
@property(nonatomic) NSMutableArray *array;
@property(nonatomic) NSMutableDictionary *barcodeFormatTable;
@property(nonatomic) NSMutableDictionary *sendToPluginDic;
@property(nonatomic) NSMutableArray *returnArray;
@property(nonatomic) NSMutableDictionary *barcodeInfoDic;
@property(nonatomic) BOOL timerStatus;
@property(nonatomic) BOOL alredySend;
@property(nonatomic) NexacroAppDelegate *nexacroAppDelegate;
@property(nonatomic) MultiQRBarcodePlugin *multiBarcodePlugin;

@end

@implementation CameraViewController2

@synthesize isUseFrontCamera;
@synthesize isUseTextLabel;
@synthesize isUseTimer;
@synthesize isUseSoundEffect;
@synthesize isUseAutoCapture;
@synthesize selectingCount;
@synthesize setBarcodeFormat;
@synthesize setLimitTime;
@synthesize setLimitCount;
@synthesize setZoomFactor;
@synthesize boxColor;


- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    
    return UIInterfaceOrientationMaskPortrait;
}

- (NSString *)stringForDetector:(Detector)detector {
    switch (detector) {
        case DetectorOnDeviceBarcode:
            return @"Barcode Scanning";
    }
}


#pragma mark - viewDidLoad
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _alredySend = NO;
    
    if (self.boxColor == nil )
        self.boxColor = UIColor.yellowColor;
    
    _nexacroAppDelegate = ((NexacroAppDelegate *)[[UIApplication sharedApplication] delegate]);
    AppViewController *rootVC =  (AppViewController*)_nexacroAppDelegate.mainViewController;
    _multiBarcodePlugin = rootVC.multiBarcodePlugin;
    
    self.view.layer.shouldRasterize = YES;
    self.view.layer.rasterizationScale = [UIScreen mainScreen].scale;
    _cameraView.layer.shouldRasterize = YES;
    _cameraView.layer.rasterizationScale = [UIScreen mainScreen].scale;
    
    self.view.backgroundColor = [UIColor blackColor];
    _cameraView.backgroundColor = [UIColor blackColor];
    
    _array = [[NSMutableArray alloc]init];
    _barcodeFormatTable = [[NSMutableDictionary alloc]init];
    _barcodeInfoDic = [[NSMutableDictionary alloc]init];
    
    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *largeConfig = [UIImageSymbolConfiguration configurationWithPointSize:60 weight:UIImageSymbolWeightBold scale:UIImageSymbolScaleLarge];
        
        UIImage *largeBoldDoc = [UIImage systemImageNamed:@"circle.fill" withConfiguration:largeConfig];
        [_cameraBtn setImage:largeBoldDoc forState:UIControlStateNormal];
    } else {
        // Fallback on earlier versions
    }
    
    self.currentDetector = DetectorOnDeviceBarcode;
    _isUsingFrontCamera = isUseFrontCamera;
    _captureSession = [[AVCaptureSession alloc] init];
    // 캡처세션 초기화
    _sessionQueue = dispatch_queue_create(sessionQueueLabel.UTF8String, nil);
    
    _previewOverlayView = [[UIImageView alloc] initWithFrame:CGRectZero];
    _previewOverlayView.contentMode = UIViewContentModeScaleAspectFill;
    _previewOverlayView.translatesAutoresizingMaskIntoConstraints = NO;
    _annotationOverlayView = [[UIView alloc] initWithFrame:CGRectZero];
    _annotationOverlayView.translatesAutoresizingMaskIntoConstraints = NO;
    
    self.previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:_captureSession];
    
    self.previewLayer.connection.videoOrientation = AVCaptureVideoOrientationPortrait;
    //self.previewLayer.connection.videoOrientation = AVCaptureVideoOrientationLandscapeLeft
    
    [self setUpPreviewOverlayView];
    [self setUpAnnotationOverlayView];
    [self setUpCaptureSessionOutput];
    [self setUpCaptureSessionInput];
}

#pragma mark - viewDidAppear
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    //if ( [self grantCameraPermission] )
    [self startSession];
    
    _timerStatus = YES;
    
    /*
     
     1. 모듈 인스턴스 생성 - > 콜 메소드 ->
     2. ( viewDidLoad  [ onCreated() ] : UI 초기화 및 켑쳐 세션 초기화 ) ->
     3. ( viewDidApper [ onStart() ]   : 캡쳐 스타트 ) ->
     4. ( AVCaptureVideoDataOutputSampleBufferDelegate  : 해당 델리게이터를 통해 마지막 프레임에 이미지 버퍼를 받아옴 ) ->
     5. ( scanBarcodesOnDeviceInImage 함수를 통해 마지막 버퍼의 이미지를 분석 ) ->
     6. 상기 함수에서 MLKBarcodeScanner 스캐너 인스턴스가 스캔결과를 MLKBarcode 인스턴스로 내보냄 ->
     7. 캡처 버튼 클릭시 스캔 결과인 MLKBarcode 인스턴스를 json 형식으로 매핑후 모듈로 전송
     8. 넥사크로로 리턴
     
     */
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    [self stopSession];
}

- (void)viewSetPorfit {
    
    if (@available(iOS 16.0, *)) {
        
        UIWindowScene *scene ;
        NSArray *connectedScenes = [[[UIApplication sharedApplication] connectedScenes] allObjects];
        if ([connectedScenes count] > 0) {
            scene = (UIWindowScene *)connectedScenes[0];
        }
        
        UIWindowSceneGeometryPreferences *preferences = [[UIWindowSceneGeometryPreferencesIOS alloc] initWithInterfaceOrientations:UIInterfaceOrientationMaskPortrait];
        
        [scene requestGeometryUpdateWithPreferences:preferences errorHandler:^(NSError * _Nonnull error) {
            // Handle error here
        }];
        
    } else {
        NSNumber *value = [NSNumber numberWithInt:UIDeviceOrientationPortrait];
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
    }
}

- (void)viewDidLayoutSubviews {
    
    [super viewDidLayoutSubviews];
    _previewLayer.frame = _cameraView.frame;
    
    [self viewSetPorfit];
}


#pragma mark - 버튼 이벤트
- (IBAction)onClick:(id)sender {
    
    _alredySend = YES;
    // 비동기처리 Flag 값
    
    if (self.isUseSoundEffect == YES)
        [self playSound];
    
    [self sendToMultiBarcodePlugin];
    // 플러그인에 바코드에 대한 정보를 전송하는 함수 호출
    
    [self dismissViewControllerAnimated:NO completion:nil];
    // 뷰 종료
}

- (IBAction)onBackBtnClick:(id)sender {
    
    _alredySend = YES;
    // 비동기처리 Flag 값
    
    [_multiBarcodePlugin sendEx:CODE_ERROR eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:@"User Cancel"];
    
    [self dismissViewControllerAnimated:NO completion:nil];
    // 뷰 종료
}

#pragma mark - 넥사크로로 전송 ( 테스트 코드 )

- (void) sendToMultiBarcodePlugin2 {
    
    NSArray *test = [self sortedMutableArrayByDuplicateValue:_array];
    int a = 2;
    
    @try {
        for( int i = 1; i <= a; i++  ) {
            NSLog(@"%@",[test objectAtIndex: [test count] - i ]);
        }
    } @catch (NSException *exception) {
        [_multiBarcodePlugin send:CODE_ERROR withMsg:[exception description]];
    } @finally {
        NSLog(@"Finish");
    }
}

#pragma mark - 사운드 재생 ( 테스트 코드 )

- (void) playSound {
    @try {
        NSError *error;
        // 음악 파일 경로 이름 ( Sample )
        NSString *soundFilePath = [[NSBundle mainBundle] pathForResource:@"Sample" ofType:@"mp3"];
        // URL로 변환
        NSURL *soundFileURL = [NSURL fileURLWithPath:soundFilePath];
        // AVAudioPlayer 객체 생성
        AVAudioPlayer *player = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL error:&error];
        // 재생
        
        if ( error == nil )
            [player play];
        else
            [_multiBarcodePlugin sendEx:CODE_ERROR eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:error.description];
        
    } @catch (NSException *exception) {
        [_multiBarcodePlugin sendEx:CODE_ERROR eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:exception.description];
    } @finally {
        return;
    }
}


#pragma mark - 배열 요소별 누적 된 횟수 구하는 로직

- (NSMutableDictionary*) getFrequencyCountsDic {
    
    NSMutableDictionary *frequencyCounts = [NSMutableDictionary dictionary];
    
    for (id element in _array) {
        NSNumber *count = frequencyCounts[element];
        if (count == nil) {
            count = @(0);
        }
        count = @(count.intValue + 1);
        frequencyCounts[element] = count;
    }
    
    return frequencyCounts;
}


#pragma mark - 넥사크로로 전송
- (void) sendToMultiBarcodePlugin {
    
    if ( self.selectingCount <= 0  )
        [_multiBarcodePlugin send:CODE_ERROR withMsg:@"Count Set is null"];
    else {
        @try {
            
            NSMutableDictionary *frequencyCounts = [self getFrequencyCountsDic];
            NSArray *sortedKeys = [self sortedMutableArrayByDuplicateValue:_array];
            NSString *mostFrequentElement = [sortedKeys lastObject];
            
            NSLog(@"가장 많이 중복된 벨류 : %@", mostFrequentElement);
            NSLog(@"총 누적된 바코드 벨류의 개수 : %lu",(unsigned long)sortedKeys.count);
            NSLog(@"유저가 셋팅한 카운트 할 바코드 벨류의 개수 : %lu", self.selectingCount );
            
            _returnArray = [[NSMutableArray alloc]init];
            
            for ( int i = 0; i < self.selectingCount; i ++ ) {
                int idx = i + 1;
                
                NSString *mapKey    = sortedKeys[sortedKeys.count - idx];
                // DisPlayerValue : rawValue를 가공한 사용자 친화적인 바코드 값
                NSString *rawValue  = [[_barcodeFormatTable valueForKey:mapKey]valueForKey:@"rawValue"];
                // 원시데이터를 UTF-8로 인코딩 한 값.
                NSString *mapValue  = [[_barcodeFormatTable valueForKey:mapKey]valueForKey:@"format"];
                // 바코드 값을 기준으로 포맷 테이블에서 해당 바코드의 포멧을 가져옴
                NSString *valueType = [[_barcodeFormatTable valueForKey:mapKey]valueForKey:@"displayValueType"];
                // 바코드의 벨류 타입
                NSString *count     = [frequencyCounts valueForKey:mapKey];
                // 바코드 값을 기준으로 해당 바코드의 버퍼마다 누적 카운팅 된 숫자를 가져옴
                
                NSLog(@"상위 %d번째로 많이 누적 캡쳐된 바코드의 벨류: %@ 포멧 : %@ 누적 캡처된 수 : %@", idx, mapKey,mapValue,count);
                
                //TODO 중복값을 제거한 바코드 포맷 테이블 [ 키 : 바코드 로우데이터 , 벨류 : 포멧 ]과 누적된 값이 상위로 정의 된 NSDic에서 키 벨류로 다시 매핑하기
                
                NSDictionary *infoDic = @{
                    @"format"           : mapValue,
                    @"displayValue"     : mapKey,
                    @"rawValue"         : rawValue,
                    @"displayValueType" : valueType
                };
                
                [_returnArray addObject:infoDic];
            }
        } @catch (NSException *exception) {
            if ( [exception.name isEqualToString:@"NSRangeException"])
                NSLog(@"%@",[exception description]);
            else
                //[_multiBarcodePlugin send:CODE_ERROR withMsg:[exception description]];
                [_multiBarcodePlugin sendEx:CODE_ERROR eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:[exception description]];
        } @finally {
            
            if (_returnArray.count <= 0)
                [_multiBarcodePlugin sendEx:CODE_SUCCES eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:@"No barcodes captured"];
            else
                [_multiBarcodePlugin sendEx:CODE_SUCCES eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:(NSString*)_returnArray];
            
            [_array removeAllObjects];
            [_barcodeFormatTable removeAllObjects];
            [_returnArray removeAllObjects];
        }
    }
}

#pragma mark - MLKit 스캔결과
- (void)scanBarcodesOnDeviceInImage:(MLKVisionImage *)image
                              width:(CGFloat)width
                             height:(CGFloat)height
                            options:(MLKBarcodeScannerOptions *)options {
    
    MLKBarcodeScanner *scanner = [MLKBarcodeScanner barcodeScannerWithOptions:options];
    // '스캐너 옵션'을 기준으로 '스캐너' 인스턴스 생성
    
    NSError *error;
    
    NSArray<MLKBarcode *> *barcodes = [scanner resultsInImage:image error:&error];
    
    /*
     - (void)processImage:(nonnull id<MLKCompatibleImage>)image
     completion:(nonnull MLKBarcodeScanningCallback)completion;
     
     고정된 이미지 처리
     */
    
    __weak typeof(self) weakSelf = self;
    dispatch_sync(dispatch_get_main_queue(), ^{
        // UI Thread에서 사용한다.
        
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf removeDetectionAnnotations];
        [strongSelf updatePreviewOverlayViewWithLastFrame];
        // UI 작업등을 라스트 프레임에 업데이트 한다
        
        if (error != nil) {
            NSLog(@"Failed to scan barcodes with error: %@", error.localizedDescription);
            [_multiBarcodePlugin sendEx:CODE_ERROR eventID:@"_oncallback" serviceID:SERVICE_ID andMsg:error.localizedDescription];
            return;
        }
        
        if (barcodes.count == 0) {
            //NSLog(@"On-Device barcode scanner returned no results.");
            //실시간으로 캡쳐된 바코드의 값이 존재하지 않을때 로그를 표시 했으나 개발단계에서도 너무 많은 로그량이 찍혀서 주석처리
            return;
        }
        for (MLKBarcode *barcode in barcodes) {
            CGRect normalizedRect = CGRectMake( barcode.frame.origin.x / width,       // X
                                               (barcode.frame.origin.y ) / height,      // Y
                                               barcode.frame.size.width / width,     // Width
                                               barcode.frame.size.height / height);  // Height
            
            CGRect standardizedRect = CGRectStandardize(
                                                        [strongSelf.previewLayer rectForMetadataOutputRectOfInterest:normalizedRect]);
            [UIUtilities addRectangle:standardizedRect
                               toView:strongSelf.annotationOverlayView
             //color:UIColor.greenColor
                                color:self.boxColor];
            
            // 포커스 된 바코드 영역을 MLKit Result를 통해 화면에 그리는 UI 작업
            if ( self.isUseTextLabel == YES ) {
                CGRect normalizedlabelRect = CGRectMake((barcode.frame.origin.x ) / width,            // X
                                                        (barcode.frame.origin.y ) / height,           // Y
                                                        (barcode.frame.size.width / width) / 5,       // Width
                                                        (barcode.frame.size.height / height) / 2 );   // Height
                
                CGRect standardizedlabelRect = CGRectStandardize(
                                                                 [strongSelf.previewLayer rectForMetadataOutputRectOfInterest:normalizedlabelRect]);
                
                UILabel *label = [self getTextLabelWithCGRect:&standardizedlabelRect withDisplayValue:barcode.displayValue];
                [strongSelf.annotationOverlayView addSubview:label];
            }
            
            // 포커스된 바코드영역에 텍스트 라벨을 화면에 그리는 UI 작업
            NSDictionary *qrBarcodeInfoDic = @{
                @"format"    : [NSString stringWithFormat:@"%ld",(long)barcode.format],
                @"rawValue"  : barcode.rawValue,
                @"displayValueType" : [NSString stringWithFormat:@"%ld",(long)barcode.valueType],
                @"displayValue" : barcode.displayValue
            };
            
            [_barcodeFormatTable setValue:qrBarcodeInfoDic forKey:barcode.displayValue];
            [_array addObject:barcode.displayValue];
            
            if ( isUseAutoCapture == YES ) {
                if ( _timerStatus == YES ) {
                    _timerStatus = NO;
                    [self startTimer];
                }
                
                if ( _array.count >= self.setLimitCount ) {
                    _alredySend = YES;
                    if (self.isUseSoundEffect == YES)
                        [self playSound];
                    [self sendToMultiBarcodePlugin];
                    [self dismissViewControllerAnimated:NO completion:nil];
                    // 뷰 종료
                }
            }
        }
    });
}

#pragma mark - 타이머 시작
-(void)startTimer {
    NSString *userInfo = @"AutoScan Timer Start";
    [NSTimer scheduledTimerWithTimeInterval:self.setLimitTime target:self selector:@selector(timerFire:) userInfo:userInfo repeats:NO];
}

#pragma mark - 타이머 핸들러
-(void)timerFire:(NSTimer*)timer {
    NSLog(@"timerFire!");
    if (_alredySend == NO) {
        if (self.isUseSoundEffect == YES)
            [self playSound];
        [self sendToMultiBarcodePlugin];
        [self dismissViewControllerAnimated:NO completion:nil];
    }
}

#pragma mark - 중복된 값 카운팅 후 정렬 함수

- (NSArray*)sortedMutableArrayByDuplicateValue : (NSMutableArray*) array {
    
    NSCountedSet *countedSet = [[NSCountedSet alloc]initWithArray:array];
    
    NSArray *sortedArray = [[countedSet allObjects] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        NSUInteger count1 = [countedSet countForObject:obj1];
        NSUInteger count2 = [countedSet countForObject:obj2];
        return count1 - count2;
    }];
    
    return sortedArray;
}


#pragma mark - UI 영역
- (void)setUpCaptureSessionOutput {
    __weak typeof(self) weakSelf = self;
    dispatch_async(_sessionQueue, ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf == nil) {
            NSLog(@"Failed to setUpCaptureSessionOutput because self was deallocated");
            return;
        }
        [strongSelf.captureSession beginConfiguration];
        // When performing latency tests to determine ideal capture settings,
        // run the app in 'release' mode to get accurate performance metrics
        strongSelf.captureSession.sessionPreset = AVCaptureSessionPresetMedium;
        
        AVCaptureVideoDataOutput *output = [[AVCaptureVideoDataOutput alloc] init];
        output.videoSettings = @{
            (id)
            kCVPixelBufferPixelFormatTypeKey : [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA]
        };
        output.alwaysDiscardsLateVideoFrames = YES;
        dispatch_queue_t outputQueue = dispatch_queue_create(videoDataOutputQueueLabel.UTF8String, nil);
        
        [output setSampleBufferDelegate:self queue:outputQueue];
        
        // 샘플 버퍼 델리게이트와 콜백을 유도하는 큐를 세팅
        // outputQueue : 비디오 프레임을 순차적으로 받는 시리얼 큐
        
        if ([strongSelf.captureSession canAddOutput:output]) {
            [strongSelf.captureSession addOutput:output];
            [strongSelf.captureSession commitConfiguration];
        } else {
            NSLog(@"%@", @"Failed to add capture session output.");
        }
    });
}
#pragma mark 텍스트 라벨 추가 함수
-(UILabel*)getTextLabelWithCGRect :(CGRect*) rect
                  withDisplayValue:(NSString*) displayValue {
    
    UILabel *label = [[UILabel alloc] initWithFrame:*rect];
    label.numberOfLines = 0;
    NSMutableString *description = [NSMutableString new];
    
    if (displayValue) {
            [description appendString:displayValue];
    }
    
    label.text = description;
    label.textAlignment = NSTextAlignmentCenter;
    label.adjustsFontSizeToFitWidth = NO;
    label.textColor = [UIColor blackColor];
    label.backgroundColor = [UIColor yellowColor];
    label.layer.borderWidth = 1.0;
    label.layer.borderColor = [UIColor yellowColor].CGColor;
    
    //[strongSelf rotateView:label orientation:image.orientation];
    //[strongSelf.annotationOverlayView addSubview:label];
    
    return label;
}


#pragma mark 카메라 인스턴스 ( Zoom 관련 )
- (void)setUpCaptureSessionInput {
    __weak typeof(self) weakSelf = self;
    dispatch_async(_sessionQueue, ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (strongSelf == nil) {
            NSLog(@"Failed to setUpCaptureSessionInput because self was deallocated");
            return;
        }
        
        
        AVCaptureDevicePosition cameraPosition =
        strongSelf.isUsingFrontCamera ? AVCaptureDevicePositionFront : AVCaptureDevicePositionBack;
        AVCaptureDevice *device = [strongSelf captureDeviceForPosition:cameraPosition];
        // 카메라 인스턴스 생성
        
        if (device) {
            
            [strongSelf.captureSession beginConfiguration];
            NSArray<AVCaptureInput *> *currentInputs = strongSelf.captureSession.inputs;
            for (AVCaptureInput *input in currentInputs) {
                [strongSelf.captureSession removeInput:input];
            }
            NSError *error;
            AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device
                                                                                error:&error];
            if (error) {
                NSLog(@"Failed to create capture device input: %@", error.localizedDescription);
                return;
            } else {
                if ([strongSelf.captureSession canAddInput:input]) {
                    [strongSelf.captureSession addInput:input];
                    
                    if ([device lockForConfiguration:&error]) {
                        
                        //CGFloat zoomFactor = 3.0;
                        
                        device.videoZoomFactor = self.setZoomFactor;
                        [device unlockForConfiguration];
                        
                    } else {
                        NSLog(@"%@",[error description]);
                    }
                } else {
                    NSLog(@"%@", @"Failed to add capture session input.");
                }
            }
            [strongSelf.captureSession commitConfiguration];
        } else {
            NSLog(@"Failed to get capture device for camera position: %ld", cameraPosition);
        }
    });
}

- (void)startSession {
    __weak typeof(self) weakSelf = self;
    dispatch_async(_sessionQueue, ^{
        [weakSelf.captureSession startRunning];
    });
}


- (void)stopSession {
    __weak typeof(self) weakSelf = self;
    dispatch_async(_sessionQueue, ^{
        [weakSelf.captureSession stopRunning];
    });
}

- (void)setUpPreviewOverlayView {
    [_cameraView addSubview:_previewOverlayView];
    [NSLayoutConstraint activateConstraints:@[
        [_previewOverlayView.centerYAnchor  constraintEqualToAnchor:_cameraView.centerYAnchor],
        [_previewOverlayView.centerXAnchor  constraintEqualToAnchor:_cameraView.centerXAnchor],
        [_previewOverlayView.leadingAnchor  constraintEqualToAnchor:_cameraView.leadingAnchor],
        [_previewOverlayView.trailingAnchor constraintEqualToAnchor:_cameraView.trailingAnchor]
    ]];
}

- (void)setUpAnnotationOverlayView {
    [_cameraView addSubview:_annotationOverlayView];
    [NSLayoutConstraint activateConstraints:@[
        [_annotationOverlayView.topAnchor      constraintEqualToAnchor:_cameraView.topAnchor],
        [_annotationOverlayView.leadingAnchor  constraintEqualToAnchor:_cameraView.leadingAnchor],
        [_annotationOverlayView.trailingAnchor constraintEqualToAnchor:_cameraView.trailingAnchor],
        [_annotationOverlayView.bottomAnchor   constraintEqualToAnchor:_cameraView.bottomAnchor]
    ]];
}

- (AVCaptureDevice *)captureDeviceForPosition:(AVCaptureDevicePosition)position {
    if (@available(iOS 10, *)) {
        AVCaptureDeviceDiscoverySession *discoverySession = [AVCaptureDeviceDiscoverySession
                                                             discoverySessionWithDeviceTypes:@[ AVCaptureDeviceTypeBuiltInWideAngleCamera ]
                                                             mediaType:AVMediaTypeVideo
                                                             position:AVCaptureDevicePositionUnspecified];
        for (AVCaptureDevice *device in discoverySession.devices) {
            if (device.position == position) {
                return device;
            }
        }
    }
    return nil;
}


- (void)removeDetectionAnnotations {
    for (UIView *annotationView in _annotationOverlayView.subviews) {
        [annotationView removeFromSuperview];
    }
}

- (void)updatePreviewOverlayViewWithLastFrame {
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(_lastFrame);
    [self updatePreviewOverlayViewWithImageBuffer:imageBuffer];
}

- (void)updatePreviewOverlayViewWithImageBuffer:(CVImageBufferRef)imageBuffer {
    if (imageBuffer == nil) {
        return;
    }
    UIImageOrientation orientation =
    _isUsingFrontCamera ? UIImageOrientationLeftMirrored : UIImageOrientationRight;
    UIImage *image = [UIUtilities UIImageFromImageBuffer:imageBuffer orientation:orientation];
    _previewOverlayView.image = image;
}

- (void)rotateView:(UIView *)view orientation:(UIImageOrientation)orientation {
    CGFloat degree = 0.0;
    switch (orientation) {
        case UIImageOrientationUp:
            break;
        case UIImageOrientationUpMirrored:
            degree = 90.0;
            break;
        case UIImageOrientationRightMirrored:
        case UIImageOrientationLeft:
            degree = 180.0;
            
            break;
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            degree = 270.0;
            
            break;
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
            degree = 0.0;
            break;
    }
    view.transform = CGAffineTransformMakeRotation(degree * 3.141592654 / 180);
}


#pragma mark - 캡쳐영역 ( AVCaptureVideoDataOutputSampleBufferDelegate )

- (void)captureOutput:(AVCaptureOutput *)output
didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer
       fromConnection:(AVCaptureConnection *)connection {
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    // AVCaptureVideoDataOutputSampleBuffer 델리게이트를 통해 실시간으로 캡쳐된 동영상의 프레임을 버퍼로 해당 뷰컨트롤러에 받는다
    // AVCaptureVideoDataOutputSampleBufferDelegate 는 video data output 에서 sample buffer를 받아오며, 받아오는 video data output의 상태를 감시한다.
    
    if (imageBuffer)
    {
        // Evaluate `self.currentDetector` once to ensure consistency throughout this method since it
        // can be concurrently modified from the main thread.
        Detector activeDetector = self.currentDetector;
        
        _lastFrame = sampleBuffer;
        
        // 프레임 단위로 버퍼에 들어가서 이미지를 분석한다.
        MLKVisionImage *visionImage = [[MLKVisionImage alloc] initWithBuffer:sampleBuffer];
        // 마지막 버퍼를 기준으로 비전이미지 인스턴스 생성
        // 비전 이미지 : 비전 감지에 사용되는 이미지 또는 이미지 버퍼
        
        UIImageOrientation orientation = [UIUtilities
                                          imageOrientationFromDevicePosition:_isUsingFrontCamera ? AVCaptureDevicePositionFront
                                          : AVCaptureDevicePositionBack];
        
        //디바이스의 회전방향을 참조해서 이미지 방향을 가져온다.
        visionImage.orientation = orientation;
        // 비전 이미지 방향설정
        
        CGFloat imageWidth = CVPixelBufferGetWidth(imageBuffer);
        CGFloat imageHeight = CVPixelBufferGetHeight(imageBuffer);
        // 버퍼를 통해 이미지 가로세로 길이 Get
        
        switch (activeDetector)
        {
            case DetectorOnDeviceBarcode: {
                MLKBarcodeScannerOptions *options = [[MLKBarcodeScannerOptions alloc] initWithFormats:
                                                     self.setBarcodeFormat
                                                     
                ];
                
                [self scanBarcodesOnDeviceInImage:visionImage
                                            width:imageWidth
                                           height:imageHeight
                                          options:options];
                break;
            }
        }
    } else {
        NSLog(@"%@", @"Failed to get image buffer from sample buffer.");
    }
}

@end

NS_ASSUME_NONNULL_END
